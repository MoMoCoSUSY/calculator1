/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Get24GamePane$Get24
/*     */ {
/* 136 */   private int[] arr = new int[4];
/* 137 */   private String[] step = new String[3];
/*     */   
/*     */   private Get24GamePane$Get24(Get24GamePane paramGet24GamePane) {}
/*     */   
/* 141 */   public int[] getNums() { do { for (int i = 0; i < 4; i++) {
/* 142 */         this.arr[i] = (1 + (int)(Math.random() * 10.0D));
/*     */       }
/* 144 */     } while (!m1(this.arr, 0));
/*     */     
/*     */ 
/* 147 */     return this.arr;
/*     */   }
/*     */   
/*     */   public String[] getSolution() {
/* 151 */     return this.step;
/*     */   }
/*     */   
/*     */   private boolean m1(int[] arr, int h) {
/* 155 */     if (h == arr.length - 1)
/* 156 */       return m2(arr, 1, arr[0]);
/* 157 */     for (int i = h; i < arr.length; i++) {
/* 158 */       int tmp = arr[h];
/* 159 */       arr[h] = arr[i];
/* 160 */       arr[i] = tmp;
/* 161 */       if (m1(arr, h + 1))
/* 162 */         return true;
/* 163 */       arr[i] = arr[h];
/* 164 */       arr[h] = tmp;
/*     */     }
/* 166 */     return false;
/*     */   }
/*     */   
/* 169 */   private char[] op = { '+', '-', '*', '/' };
/*     */   
/* 171 */   private boolean m2(int[] arr, int h, int a) { int b = arr[h];
/* 172 */     for (int i = 0; i < 4; i++) { int r;
/* 173 */       int r; if (i == 0) {
/* 174 */         r = a + b; } else { int r;
/* 175 */         if (i == 1) {
/* 176 */           r = a - b; } else { int r;
/* 177 */           if (i == 2) {
/* 178 */             r = a * b;
/*     */           } else {
/* 180 */             if (a % b != 0)
/* 181 */               return false;
/* 182 */             r = a / b;
/*     */           } } }
/* 184 */       if (h == 3) {
/* 185 */         if (r == 24) {
/* 186 */           this.step[(h - 1)] = String.format("%d%c%d=%d", new Object[] { Integer.valueOf(a), Character.valueOf(this.op[i]), Integer.valueOf(b), Integer.valueOf(r) });
/* 187 */           return true;
/*     */         }
/*     */       }
/* 190 */       else if (m2(arr, h + 1, r)) {
/* 191 */         this.step[(h - 1)] = String.format("%d%c%d=%d", new Object[] { Integer.valueOf(a), Character.valueOf(this.op[i]), Integer.valueOf(b), Integer.valueOf(r) });
/* 192 */         return true;
/*     */       }
/*     */     }
/* 195 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Calculator.jar!\Get24GamePane$Get24.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */