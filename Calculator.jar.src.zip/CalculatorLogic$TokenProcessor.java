/*     */ import java.util.ArrayList;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CalculatorLogic$TokenProcessor
/*     */ {
/*     */   private CalculatorLogic$TokenProcessor(CalculatorLogic paramCalculatorLogic) {}
/*     */   
/*     */   public void createToken(String word)
/*     */     throws Exception
/*     */   {
/*  32 */     if (fitNum(word)) {
/*  33 */       CalculatorLogic.access$0(this.this$0).add(new Token(3, word));
/*  34 */     } else if (fitFounction(word)) {
/*  35 */       CalculatorLogic.access$0(this.this$0).add(new Token(4, word));
/*  36 */     } else if (fitId(word)) {
/*  37 */       CalculatorLogic.access$0(this.this$0).add(new Token(5, word));
/*  38 */       CalculatorLogic.access$1(this.this$0).put(word, null);
/*     */     } else {
/*  40 */       throw new Exception("Illegal chatacter or number! Try again");
/*     */     }
/*     */   }
/*     */   
/*  44 */   public void getTokenStream(String input) throws Exception { StringBuffer tmp = new StringBuffer();
/*  45 */     for (int i = 0; i < input.length(); i++) {
/*  46 */       char ch = input.charAt(i);
/*  47 */       if ((ch == ' ') || (fitSep(ch)) || (fitOP(ch))) {
/*  48 */         if (tmp.length() != 0) {
/*  49 */           createToken(tmp.toString());
/*  50 */           tmp = new StringBuffer("");
/*     */         }
/*  52 */         if (fitSep(ch)) {
/*  53 */           CalculatorLogic.access$0(this.this$0).add(new Token(1, ch));
/*  54 */         } else if (fitOP(ch)) {
/*  55 */           CalculatorLogic.access$0(this.this$0).add(new Token(2, ch));
/*     */         }
/*     */       } else {
/*  58 */         tmp.append(ch);
/*     */       } }
/*  60 */     if (tmp.length() != 0)
/*  61 */       createToken(tmp.toString());
/*  62 */     if (CalculatorLogic.access$0(this.this$0).size() == 0)
/*  63 */       throw new Exception("Empty Input!");
/*     */   }
/*     */   
/*     */   public boolean fitSep(String word) {
/*  67 */     char ch = word.charAt(0);
/*  68 */     return (word.length() == 1) && ((ch == '(') || (ch == ')') || (ch == ',') || (ch == '%'));
/*     */   }
/*     */   
/*     */   public boolean fitOP(String word) {
/*  72 */     char ch = word.charAt(0);
/*  73 */     return (word.length() == 1) && ((ch == '+') || (ch == '-') || (ch == '*') || (ch == '/'));
/*     */   }
/*     */   
/*     */   public boolean fitNum(String word) {
/*     */     try {
/*  78 */       if (word.contains("."))
/*  79 */         Double.parseDouble(word); else
/*  80 */         Integer.parseInt(word);
/*  81 */       return true;
/*     */     } catch (Exception e) {}
/*  83 */     return false;
/*     */   }
/*     */   
/*     */   public boolean fitFounction(String word) {
/*     */     String[] arrayOfString;
/*  88 */     int j = (arrayOfString = CalculatorLogic.access$2(this.this$0)).length; for (int i = 0; i < j; i++) { String f = arrayOfString[i];
/*  89 */       if (word.equals(f))
/*  90 */         return true; }
/*  91 */     return false;
/*     */   }
/*     */   
/*     */   public boolean fitId(String word) {
/*  95 */     int state = 0;
/*  96 */     char ch = '$';
/*  97 */     for (int i = 0; i < word.length(); i++) {
/*  98 */       ch = word.charAt(i);
/*  99 */       if (state == 0) {
/* 100 */         if ((ch == '$') || (ch == '_') || ((ch <= 'z') && (ch >= 'a')) || ((ch <= 'Z') && (ch >= 'A')))
/* 101 */           state = 1; else {
/* 102 */           return false;
/*     */         }
/* 104 */       } else if (state == 1)
/*     */       {
/* 106 */         if (((ch > 'z') || (ch < 'a')) && ((ch > 'Z') || (ch < 'A')) && ((ch > '9') || (ch < '0')))
/*     */         {
/* 108 */           return false; }
/*     */       }
/*     */     }
/* 111 */     return (word.length() > 1) || ((ch != '_') && (ch != '$'));
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Calculator.jar!\CalculatorLogic$TokenProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */