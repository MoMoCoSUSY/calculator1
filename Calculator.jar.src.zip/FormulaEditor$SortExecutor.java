/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FormulaEditor$SortExecutor
/*     */ {
/*     */   private FormulaEditor$SortExecutor(FormulaEditor paramFormulaEditor) {}
/*     */   
/*     */   public void changeOrder()
/*     */   {
/* 307 */     if (FormulaEditor.access$1(this.this$0).equals("name")) {
/* 308 */       String[] arr = new String[FormulaEditor.access$3(this.this$0).size()];
/* 309 */       for (int i = 0; i < arr.length; i++)
/* 310 */         arr[i] = FormulaEditor.FormulaCheckBox.access$0((FormulaEditor.FormulaCheckBox)FormulaEditor.access$3(this.this$0).get(i)).id;
/* 311 */       sort(arr);
/*     */     }
/* 313 */     else if (FormulaEditor.access$1(this.this$0).equals("count")) {
/* 314 */       Integer[] arr = new Integer[FormulaEditor.access$3(this.this$0).size()];
/* 315 */       for (int i = 0; i < arr.length; i++)
/* 316 */         arr[i] = Integer.valueOf(FormulaEditor.FormulaCheckBox.access$0((FormulaEditor.FormulaCheckBox)FormulaEditor.access$3(this.this$0).get(i)).count);
/* 317 */       sort(arr);
/*     */     }
/* 319 */     else if (FormulaEditor.access$1(this.this$0).equals("level")) {
/* 320 */       String[] arr = new String[FormulaEditor.access$3(this.this$0).size()];
/* 321 */       for (int i = 0; i < arr.length; i++)
/* 322 */         arr[i] = FormulaEditor.FormulaCheckBox.access$0((FormulaEditor.FormulaCheckBox)FormulaEditor.access$3(this.this$0).get(i)).level;
/* 323 */       sort(arr);
/*     */     }
/*     */   }
/*     */   
/*     */   private <E extends Comparable<E>> void sort(E[] arr)
/*     */   {
/* 329 */     for (int i = 1; i < arr.length; i++) {
/* 330 */       E tmpA = arr[i];
/* 331 */       FormulaEditor.FormulaCheckBox tmpB = (FormulaEditor.FormulaCheckBox)FormulaEditor.access$3(this.this$0).get(i);
/* 332 */       for (int j = i; (j > 0) && (putAhead(tmpA, arr[(j - 1)])); j--) {
/* 333 */         arr[j] = arr[(j - 1)];
/* 334 */         FormulaEditor.access$3(this.this$0).set(j, (FormulaEditor.FormulaCheckBox)FormulaEditor.access$3(this.this$0).get(j - 1));
/*     */       }
/* 336 */       arr[j] = tmpA;
/* 337 */       FormulaEditor.access$3(this.this$0).set(j, tmpB);
/*     */     }
/*     */   }
/*     */   
/* 341 */   private <E extends Comparable<E>> boolean putAhead(E a, E b) { int n = a.compareTo(b);
/* 342 */     return ((FormulaEditor.access$9(this.this$0).equals("ASC")) && (n < 0)) || ((FormulaEditor.access$9(this.this$0).equals("DESC")) && (n > 0));
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Calculator.jar!\FormulaEditor$SortExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */