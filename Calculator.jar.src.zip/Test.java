/*    */ import javafx.application.Application;
/*    */ import javafx.stage.Stage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Test
/*    */   extends Application
/*    */ {
/* 22 */   public static void main(String[] args) { launch(args); }
/*    */   
/*    */   public void start(Stage stage) {
/* 25 */     CompleteWindow window = new CompleteWindow();
/* 26 */     window.show();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\Calculator.jar!\Test.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */