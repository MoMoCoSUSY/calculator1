/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.net.URL;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Scanner;
/*     */ import javafx.scene.control.Alert;
/*     */ import javafx.scene.control.Alert.AlertType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ExchangeRatePane$RateExchanger
/*     */ {
/*     */   private Map<String, Double> rateMap;
/*  74 */   private Alert dialog = new Alert(Alert.AlertType.INFORMATION);
/*     */   
/*  76 */   public ExchangeRatePane$RateExchanger(ExchangeRatePane paramExchangeRatePane) { this.dialog.setHeaderText(null);
/*  77 */     this.dialog.setGraphic(null);
/*  78 */     updateRate();
/*  79 */     loadExchangeRate();
/*     */   }
/*     */   
/*     */   private void updateRate() {
/*     */     try {
/*  84 */       URL url = new URL("http://hl.anseo.cn");
/*  85 */       Scanner input = new Scanner(url.openStream(), "utf-8");
/*  86 */       Map<String, Double> newRateMap = new LinkedHashMap();
/*  87 */       newRateMap.put("人民币(CNY)", Double.valueOf(1.0D));
/*  88 */       boolean start = false;
/*     */       
/*     */ 
/*  91 */       while (input.hasNext()) {
/*  92 */         String line = input.nextLine();
/*  93 */         if (start) {
/*  94 */           if (line.contains("/div>")) {
/*     */             break;
/*     */           }
/*  97 */           if (!line.matches("<li .*>.*<a .*>.*</a>.*<br><br><b .*><a .*>.*</a></b></li>")) {
/*  98 */             throw new Exception("You need to update your version");
/*     */           }
/* 100 */           int ind1 = line.indexOf("人民币 = ");
/* 101 */           int ind2 = line.indexOf("<", ind1);
/* 102 */           double rate = Double.parseDouble(line.substring(ind1 + 5, ind2));
/* 103 */           ind1 = line.indexOf(">", ind2);
/* 104 */           ind2 = line.indexOf("<", ind1);
/* 105 */           String currency = line.substring(ind1 + 1, ind2);
/* 106 */           ind1 = line.indexOf("(", ind2);
/* 107 */           ind2 = line.indexOf(")", ind1);
/* 108 */           currency = currency + line.substring(ind1, ind2 + 1);
/* 109 */           newRateMap.put(currency, Double.valueOf(rate));
/*     */         }
/* 111 */         else if (line.contains("<div id=\"rates\"")) {
/* 112 */           start = true;
/*     */         }
/*     */       }
/* 115 */       if (newRateMap.size() == 1)
/* 116 */         throw new Exception("Failed to connect to the Internet \n or you need to update your version");
/* 117 */       input.close();
/* 118 */       File f = new File("save");
/* 119 */       if (!f.exists())
/* 120 */         f.mkdirs();
/* 121 */       ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(new File(f, "exchangeRate.dat")));
/* 122 */       output.writeObject(newRateMap);
/* 123 */       output.close();
/*     */     } catch (UnknownHostException e) {
/* 125 */       this.dialog.setContentText("Failed to connect to Internet");
/* 126 */       this.dialog.showAndWait();
/*     */     }
/*     */     catch (Exception e) {
/* 129 */       this.dialog.setContentText(e.getMessage());
/* 130 */       this.dialog.showAndWait();
/*     */     }
/*     */   }
/*     */   
/*     */   private void loadExchangeRate() {
/*     */     try {
/* 136 */       ObjectInputStream in = new ObjectInputStream(new FileInputStream(new File("save/exchangeRate.dat")));
/* 137 */       this.rateMap = ((Map)in.readObject());
/* 138 */       in.close();
/*     */     } catch (FileNotFoundException e) {
/* 140 */       this.rateMap = new LinkedHashMap();
/* 141 */       this.rateMap.put("人民币(CNY)", Double.valueOf(1.0D));
/*     */     } catch (Exception localException) {}
/*     */   }
/*     */   
/*     */   public Map<String, Double> getRateMap() {
/* 146 */     return this.rateMap;
/*     */   }
/*     */   
/*     */   public double getExchangeResult(double amount, String c1, String c2) {
/* 150 */     double r1 = ((Double)this.rateMap.get(c1)).doubleValue();double r2 = ((Double)this.rateMap.get(c2)).doubleValue();
/* 151 */     return amount / r1 * r2;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Calculator.jar!\ExchangeRatePane$RateExchanger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */