/*     */ import java.util.ArrayList;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CalculatorLogic$ComputeExecutor
/*     */ {
/*     */   private ArrayList<Token> tokenStream;
/*     */   private Map<String, Double> IdMap;
/* 118 */   private int currIndex = 0;
/*     */   private Token currToken;
/*     */   
/*     */   private CalculatorLogic$ComputeExecutor(CalculatorLogic paramCalculatorLogic) {}
/*     */   
/*     */   public double exeComputing(ArrayList<Token> tokenStream, Map<String, Double> IdMap) throws Exception {
/* 124 */     this.tokenStream = tokenStream;
/* 125 */     this.IdMap = IdMap;
/* 126 */     this.currIndex = 0;
/* 127 */     nextToken();
/*     */     try {
/* 129 */       return E();
/*     */     } catch (Exception e) {
/* 131 */       throw new Exception("Syntax Exception!Try agagin");
/*     */     }
/*     */   }
/*     */   
/*     */   private String con;
/*     */   private int cat;
/* 137 */   private void nextToken() { if (this.currIndex < this.tokenStream.size()) {
/* 138 */       this.currToken = ((Token)this.tokenStream.get(this.currIndex++));
/* 139 */       this.con = this.currToken.content;
/* 140 */       this.cat = this.currToken.cat;
/*     */     }
/*     */     else {
/* 143 */       this.currToken = null;
/* 144 */       this.con = "$";
/* 145 */       this.cat = -1;
/*     */     }
/*     */   }
/*     */   
/*     */   private void match(String str) throws Exception {
/* 150 */     if (!this.con.equals(str)) {
/* 151 */       throw new Exception();
/*     */     }
/* 153 */     nextToken();
/*     */   }
/*     */   
/*     */   private double E() throws Exception
/*     */   {
/* 158 */     if ((this.con.equals("+")) || (this.con.equals("-"))) {
/* 159 */       char op = this.con.charAt(0);
/* 160 */       nextToken();
/* 161 */       double n = op == '+' ? T() : -T();
/* 162 */       n = E1(n);
/*     */     }
/* 164 */     else if ((this.cat == 3) || (this.cat == 4) || (this.cat == 5) || (this.con.equals("("))) {
/* 165 */       double n = T();
/* 166 */       n = E1(n);
/*     */     } else {
/* 168 */       throw new Exception(); }
/* 169 */     double n; return n;
/*     */   }
/*     */   
/*     */   private double E1(double in) throws Exception
/*     */   {
/* 174 */     if ((this.con.equals("+")) || (this.con.equals("-"))) {
/* 175 */       char op = this.con.charAt(0);
/* 176 */       nextToken();
/* 177 */       double n = op == '+' ? in + T() : in - T();
/* 178 */       n = E1(n);
/*     */     } else { double n;
/* 180 */       if ((this.con.equals(")")) || (this.con.equals("$")) || (this.con.equals(",")))
/* 181 */         n = in; else
/* 182 */         throw new Exception(); }
/* 183 */     double n; return n;
/*     */   }
/*     */   
/*     */   private double T() throws Exception
/*     */   {
/* 188 */     if ((this.cat == 3) || (this.cat == 4) || (this.cat == 5) || (this.con.equals("("))) {
/* 189 */       double n = F();
/* 190 */       n = T1(n);
/*     */     } else {
/* 192 */       throw new Exception(); }
/* 193 */     double n; return n;
/*     */   }
/*     */   
/*     */   private double T1(double in) throws Exception
/*     */   {
/* 198 */     if ((this.con.equals("/")) || (this.con.equals("*"))) {
/* 199 */       char op = this.con.charAt(0);
/* 200 */       nextToken();
/* 201 */       double n = op == '*' ? in * F() : in / F();
/* 202 */       n = T1(n);
/*     */     } else { double n;
/* 204 */       if ((this.con.equals("+")) || (this.con.equals("-")) || (this.con.equals(")")) || 
/* 205 */         (this.con.equals("$")) || (this.con.equals(","))) {
/* 206 */         n = in;
/*     */       } else
/* 208 */         throw new Exception(); }
/* 209 */     double n; return n;
/*     */   }
/*     */   
/*     */   private double F() throws Exception
/*     */   {
/* 214 */     if (this.cat == 3) {
/* 215 */       double n = Double.parseDouble(this.con);
/* 216 */       nextToken();
/* 217 */       if (this.con.equals("%")) {
/* 218 */         n /= 100.0D;
/* 219 */         nextToken();
/*     */       }
/*     */     }
/* 222 */     else if (this.cat == 5) {
/* 223 */       double n = ((Double)this.IdMap.get(this.con)).doubleValue();
/* 224 */       nextToken();
/* 225 */       if (this.con.equals("%")) {
/* 226 */         n /= 100.0D;
/* 227 */         nextToken();
/*     */       }
/*     */     }
/* 230 */     else if (this.con.equals("(")) {
/* 231 */       nextToken();
/* 232 */       double n = E();
/* 233 */       match(")");
/* 234 */       if (this.con.equals("%")) {
/* 235 */         n /= 100.0D;
/* 236 */         nextToken();
/*     */       }
/*     */     }
/* 239 */     else if (this.cat == 4) {
/* 240 */       double n = Function();
/* 241 */       if (this.con.equals("%")) {
/* 242 */         n /= 100.0D;
/* 243 */         nextToken();
/*     */       }
/*     */     } else {
/* 246 */       throw new Exception(); }
/* 247 */     double n; return n;
/*     */   }
/*     */   
/*     */   private double Function() throws Exception {
/* 251 */     double n = 0.0D;double a = 0.0D;double b = 0.0D;
/* 252 */     String func = this.con;
/* 253 */     if ((this.con.equals("PI")) || (this.con.equals("E")) || (this.con.equals("rand"))) {
/* 254 */       nextToken();
/* 255 */     } else if ((this.con.equals("cos")) || (this.con.equals("sin")) || 
/* 256 */       (this.con.equals("tan")) || (this.con.equals("sqrt")) || 
/* 257 */       (this.con.equals("ln")) || (this.con.equals("exp")) || 
/* 258 */       (this.con.equals("rInt"))) {
/* 259 */       nextToken();match("(");a = E();match(")");
/*     */     }
/*     */     else {
/* 262 */       nextToken();match("(");a = E();
/* 263 */       match(",");b = E();match(")");
/*     */     }
/*     */     String str1;
/* 266 */     switch ((str1 = func).hashCode()) {case 69:  if (str1.equals("E")) {} break; case 2553:  if (str1.equals("PI")) {} break; case 3458:  if (str1.equals("ln")) {} break; case 98695:  if (str1.equals("cos")) break; break; case 100893:  if (str1.equals("exp")) {} break; case 107332:  if (str1.equals("log")) {} break; case 111192:  if (str1.equals("pow")) {} break; case 113880:  if (str1.equals("sin")) {} break; case 114593:  if (str1.equals("tan")) {} break; case 3469853:  if (str1.equals("rInt")) {} break; case 3492901:  if (str1.equals("rand")) {} break; case 3538208:  if (!str1.equals("sqrt")) {
/* 267 */         return n;n = Math.cos(a); return n;
/* 268 */         n = Math.sin(a); return n;
/* 269 */         n = Math.tan(a);
/* 270 */       } else { n = Math.sqrt(a); return n;
/* 271 */         n = Math.log(a); return n;
/* 272 */         n = Math.log(b) / Math.log(a); return n;
/* 273 */         n = Math.pow(a, b); return n;
/* 274 */         n = Math.exp(a); return n;
/* 275 */         n = Math.random(); return n;
/* 276 */         n = (int)(a * Math.random()); return n;
/* 277 */         n = 3.141592653589793D; return n;
/* 278 */         n = 2.718281828459045D; }
/*     */       break; }
/* 280 */     return n;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Calculator.jar!\CalculatorLogic$ComputeExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */