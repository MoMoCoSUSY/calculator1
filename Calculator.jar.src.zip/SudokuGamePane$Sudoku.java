/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SudokuGamePane$Sudoku
/*     */ {
/*     */   private SudokuGamePane$Sudoku(SudokuGamePane paramSudokuGamePane) {}
/*     */   
/* 338 */   private int[][] numArr = new int[9][9];
/* 339 */   private ArrayList<Integer>[][] numForCell = new ArrayList[9][9];
/*     */   
/* 341 */   public boolean m(int i, int j) { ArrayList<Integer> cell = this.numForCell[i][j] = new ArrayList();
/* 342 */     cell.addAll(Arrays.asList(randomOrder()));
/* 343 */     for (int ind = 0; ind < cell.size();) {
/* 344 */       Integer tmp = (Integer)cell.get(ind);
/* 345 */       if (!check(i, j, tmp.intValue()))
/* 346 */         cell.remove(tmp); else
/* 347 */         ind++;
/*     */     }
/* 349 */     if ((i == 8) && (j == 8)) {
/* 350 */       if (cell.size() != 0) {
/* 351 */         this.numArr[i][j] = ((Integer)cell.get(0)).intValue();
/* 352 */         return true;
/*     */       }
/* 354 */       return false; }
/*     */     int nextJ;
/*     */     int nextI;
/*     */     int nextJ;
/* 358 */     if (j + 1 == 9) {
/* 359 */       int nextI = i + 1;
/* 360 */       nextJ = 0;
/*     */     }
/*     */     else {
/* 363 */       nextI = i;
/* 364 */       nextJ = j + 1;
/*     */     }
/* 366 */     for (Iterator localIterator = cell.iterator(); localIterator.hasNext();) { int n = ((Integer)localIterator.next()).intValue();
/* 367 */       this.numArr[i][j] = n;
/* 368 */       if (m(nextI, nextJ))
/* 369 */         return true;
/*     */     }
/* 371 */     return false;
/*     */   }
/*     */   
/*     */   private Integer[] randomOrder() {
/* 375 */     Integer[] arr = {
/* 376 */       Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(6), Integer.valueOf(7), Integer.valueOf(8), Integer.valueOf(9) };
/*     */     
/* 378 */     for (int i = 0; i < 9; i++) {
/* 379 */       int ind = (int)(Math.random() * 9.0D);
/* 380 */       int tmp = arr[i].intValue();
/* 381 */       arr[i] = arr[ind];
/* 382 */       arr[ind] = Integer.valueOf(tmp);
/*     */     }
/* 384 */     return arr;
/*     */   }
/*     */   
/* 387 */   private boolean check(int i, int j, int n) { for (int b = 0; b < j; b++)
/* 388 */       if (this.numArr[i][b] == n)
/* 389 */         return false;
/* 390 */     for (int a = 0; a < i; a++)
/* 391 */       if (this.numArr[a][j] == n)
/* 392 */         return false;
/* 393 */     int baseI = i - i % 3;int baseJ = j - j % 3;
/* 394 */     for (int a = baseI; a <= i; a++)
/*     */     {
/* 396 */       int endJ = a < i ? baseJ + 3 : j;
/* 397 */       for (int b = baseJ; b < endJ; b++)
/* 398 */         if (this.numArr[a][b] == n)
/* 399 */           return false;
/*     */     }
/* 401 */     return true;
/*     */   }
/*     */   
/* 404 */   public int[][] getSudoku() { m(0, 0);
/* 405 */     return this.numArr;
/*     */   }
/*     */   
/*     */   public boolean checkSudoku(int[][] numArr) {
/* 409 */     for (int i = 0; i < 9; i++) {
/* 410 */       int[] ruler = new int[9];
/* 411 */       for (int j = 0; j < 9; j++) {
/* 412 */         int ind = numArr[i][j];
/* 413 */         if (ruler[(ind - 1)] != 0) {
/* 414 */           System.out.println("11111");
/* 415 */           return false;
/*     */         }
/* 417 */         ruler[(ind - 1)] = 1;
/*     */       }
/*     */     }
/*     */     
/* 421 */     for (int j = 0; j < 9; j++) {
/* 422 */       int[] ruler = new int[9];
/* 423 */       for (int i = 0; i < 9; i++) {
/* 424 */         int ind = numArr[i][j];
/* 425 */         if (ruler[(ind - 1)] != 0) {
/* 426 */           System.out.println("22222");
/* 427 */           return false;
/*     */         }
/* 429 */         ruler[(ind - 1)] = 1;
/*     */       }
/*     */     }
/*     */     
/* 433 */     for (int i = 0; i < 9; i += 3)
/* 434 */       for (int j = 0; j < 9; j += 3) {
/* 435 */         int[] ruler = new int[9];
/* 436 */         for (int a = i; a < i + 3; a++)
/* 437 */           for (int b = j; b < j + 3; b++) {
/* 438 */             int ind = numArr[a][b];
/* 439 */             if (ruler[(ind - 1)] != 0) {
/* 440 */               System.out.println("33333");
/* 441 */               return false;
/*     */             }
/* 443 */             ruler[(ind - 1)] = 1;
/*     */           }
/*     */       }
/* 446 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\Calculator.jar!\SudokuGamePane$Sudoku.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */